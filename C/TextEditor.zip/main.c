#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct Node 
{
	int 	statno;
	char 	statement[40];
	int next;
};
struct Node textbuffer[30];
int head;

struct dfs 
{
	int 	code;
	int	statno;
	char 	statement[40];
};
struct dfs diffs[20];
int version = 0;	

char line[40];
int length_to_space(char *s) {
  char *i = s;
  while (*i != ' ' && *i != '\0') {
    i++;
  }
  return i - s;
}
char *split_space(char *line,int index) {
  char *pointer = line;
  int counted = 1;
  while (*pointer != '\0') {
    if (*pointer == ' ') {
      if (counted == index) {
        int new_size = length_to_space(++pointer);
        char *word = malloc(new_size + 1);
        for (int i = 0; i < new_size; i++) {
          word[i] = pointer[i];
        }
        word[new_size] = '\0';
        return word;
      }
      counted++;
    }
    pointer++;
  }
  return 0;
}




int basl = 0;
int a;
int editcheck = 0;
int savecur = 0 ;
void edit (char* filename);
void insert(int statno , char* stat);
void print();
void save();
void commit();
void delete(int statno);
int main(void) {
  for (int i = 0 ; i<30 ; i++)
  {
    textbuffer[i].statno = 0;
  }
  for (int i = 0 ; i<30 ; i++)
  {
    diffs[i].statno = -1;
  }
  edit("test.txt");
  char choice;
  while(1)
  {
    puts("To insert enter I\nTo delete enter D\nTo print enter P\nTo save enter S\nTo edit enter E\nTo exit enter X\nTo commit enter C");
    scanf("%s",&choice);
    if(strcmp(&choice,"I") == 0)
    {
      puts("Enter statno");
      int statno;
      scanf("%d",&statno);
      puts("Enter statement");
      char statement[40];
      scanf("%s",statement);
      insert(statno,statement);
    }
    else if(strcmp(&choice,"D") == 0)
    {
      puts("Enter statno");
      int statno;
      scanf("%d",&statno);
      delete(statno);
    }
    else if (strcmp(&choice,"P") == 0)
    {
      print();
    } 
    else if (strcmp(&choice,"S") == 0)
    {
      save();
    }
    else if (strcmp(&choice,"E") == 0)
    {
      int chver=0;
      puts("Enter version number ");
      char* filename;
      scanf("%d",&a);
      puts("Enter filename ");
      scanf("%s", filename);
      if ( a == -1 )
      {
        edit(filename);
      }
      else 
      {
      FILE *fp;
      FILE *fpp;
      char str[40];
      char *dnm[40];
      char *token;
      fp = fopen("out.dif","r+");
      int i = 0;
      while(fgets(str,sizeof(str),fp))
      {
      token = strtok(str," ");
      while(token != NULL)
        {
          dnm[i] = token;
          token = strtok(NULL," ");
          i++;
        }
        if (strcmp(dnm[1],"1") == 0 && dnm[2] != NULL)
        {
          insert(atoi(dnm[2]),dnm[3]);
        }
        else if (strcmp(dnm[1],"2") == 0 && dnm[2] != NULL)
        {
          delete(atoi(dnm[2]));
        }
        else if (strcmp(dnm[1],"-1") == 0 && chver == a)
        {
          break;
        }
        else if (strcmp(dnm[1],"-1") == 0)
         {
           chver++;
         }
      }
      fclose(fp);
    }
  }
    else if (strcmp(&choice,"X") == 0)
    {
      break;
    }
    else if (strcmp(&choice,"C") == 0)
    {
      commit();
    }
  }
  return 0;
}
void edit (char* filename)
{
  FILE *fp;
  FILE *fpp;
  FILE *third;
  char str[40];
  char str2[40];
  char first[40];
  char second[40];
  int state = 1;
  int line = 0;
  fp = fopen(filename,"r");
  fpp = fopen(filename,"r");
  third = fopen(filename,"r");
  if (fp == NULL)
  {
    printf("Could not open");
  }
  while(fgets(str, sizeof(str), fp))
  {
    struct Node temp;
    char *dnm = strchr(str,'\n');
    fscanf(fpp,"%s%*[^\n]",first);
    char *word = split_space(fgets(str2,sizeof(str2),third),1);
    if(textbuffer[line].statno == 0)
    {
      strcpy(temp.statement,word);
      temp.statno = atoi(first);
      textbuffer[line] = temp;
      if(dnm != NULL)
      {
        line++;
      }
    }
    else
    {
      line++;
    }
  }
  int firstloop = 0;
  fclose(fp);
  int i = 0;
  int arr[40];
  for (int sifir = 0 ; sifir < 40 ; sifir++)
  {
    arr[sifir] = 0;
  }
  while (textbuffer[editcheck].statno != 0)
  {
    arr[i] = textbuffer[editcheck].statno;
    i++;
    firstloop++;
    editcheck++;
  }
  for (int u = 0 ; u < firstloop ; u++)
  {
    for(int y = 0 ; y < firstloop - u ;y++)
    {
      if(arr[y] > arr[y+1])
      {
        int temp = arr[y];
        arr[y] = arr[y+1];
        arr[y+1] = temp;
      }
    }
  }
  int hbul=0;
  while (arr[1] != textbuffer[hbul].statno)
  {
    hbul++;
  }
  head = hbul;
  int x = 1;
  int y = 2;
  int current1 = 0 ;
  int current2 = 0 ;
  int dnn = 0;
  int bes = 0;
  int tut = 0;
  while (arr[y] != 0)
  {
    if (arr[x] == textbuffer[current1].statno)
    {
      if (arr[y] == textbuffer[current2].statno)
      {
        textbuffer[current1].next = current2;
        tut = current2;
        current1 = 0;
        current2 = 0;
        x++;
        y++;
      }
      else
      {
        current2++;
      }
    }
    else
    {
      current1++;
    }
  }
  textbuffer[tut].next = -1;
}
void insert(int statno , char* stat)
{
  int current = head;
  int maxc = head;
  int check = 0;
  diffs[basl].code = 1;
  diffs[basl].statno = statno;
  strcpy(diffs[basl].statement,stat);
  basl++;
  int max = 0 ;
  while (textbuffer[maxc].statno != 0)
  {
    if(textbuffer[maxc].statno > max)
    {
      max = textbuffer[maxc].statno;
    }
    else
    {
      maxc = textbuffer[maxc].next;
    }
  }
  while(textbuffer[current].statno != 0)
  {
    if(textbuffer[current].statno < statno && textbuffer[textbuffer[current].next].statno > statno)
    {
      while(1)
      {
        if(textbuffer[check].statno!=0){
          check++;
        }
        else
        {
          textbuffer[check].statno=statno;
          strcpy(textbuffer[check].statement,stat);
          break;
        }
      }
      textbuffer[check].next=textbuffer[current].next;
      textbuffer[current].next=check;
      
      editcheck++;
      break;
    }
    else if(textbuffer[current].statno > statno)
    {
      while(1)
      {
        if(textbuffer[check].statno!=0){
          check++;
        }
        else
        {
          textbuffer[check].statno=statno;
          strcpy(textbuffer[check].statement,stat);
          break;
        }
      }
      textbuffer[check].next = current;
      head = check;
      editcheck++;
      break;
    }
    else if (max < statno)
    {
      while(1)
      {
        if(textbuffer[check].statno!=0){
          check++;
        }
        else
        {
          textbuffer[check].statno=statno;
          strcpy(textbuffer[check].statement,stat);
          break;
        }
      }
      int ilerleme = head;
      while (textbuffer[ilerleme].statno != 0)
      {
        if (textbuffer[ilerleme].statno == max)
        {
          break;
        }
        ilerleme = textbuffer[ilerleme].next;
      }
      textbuffer[ilerleme].next = check;
      editcheck++;
      break;
    }
    else
    {
      current = textbuffer[current].next;
    }
  }
  
}
void print()
{
  int current = head;
  int dneme = 0 ;
  while(dneme != editcheck)
  {
    printf("State No :%d\t",textbuffer[current].statno);
    printf("Statement :%s\n",textbuffer[current].statement);
    current = textbuffer[current].next;
    dneme++;
  }
}
void save()
{
  FILE *fp;
  fp = fopen("out.dif","a+");
  if (fp)
  {

    while(diffs[savecur].statno != -1)
    {
      fprintf(fp,"%d\n",version+1);
      fprintf(fp,"%d ",diffs[savecur].code);
      fprintf(fp,"%d ",diffs[savecur].statno);
      if(diffs[savecur].code == 1){
          fprintf(fp,"%s",diffs[savecur].statement);
      }
      fprintf(fp,"\n-1\n");
      savecur++;
      
    }
    version=version+1;
  }
  fclose(fp);
}

void delete(int statno){
  int current = head;
  int check =0;
  diffs[basl].code = 2;
  diffs[basl].statno = statno;
  basl++;
  while(textbuffer[current].statno != 0)
  {
    if(textbuffer[current].statno == statno)
    {
      while(textbuffer[current].statno != 0)
      {
        
        int ileri = textbuffer[current].next;
        strcpy(textbuffer[current].statement,textbuffer[ileri].statement);
        textbuffer[current].statno = textbuffer[ileri].statno;
        current = textbuffer[current].next;
        
      }
    }
    else
    {
      current = textbuffer[current].next;
    }

  }
  editcheck--;
}


void commit()
{
  
    int q = head;
    FILE *file;
    file = fopen("test.txt","w");
    int xc=0;
    while(xc != editcheck)
    {
      fprintf(file,"%d %s\n",textbuffer[q].statno,textbuffer[q].statement);
      q = textbuffer[q].next;
      xc++;
    }
    fclose(file);
    FILE *reset;
    reset = fopen("out.dif","w");
    fprintf(reset,"%d\n",0);
    fclose(reset);
    int counterx=0;
    while(counterx<20)
    {
        diffs[counterx].code=0;
        strcpy(diffs[counterx].statement,"");
        diffs[counterx].statno=0;
        version=0;
        counterx++; 
    }
}