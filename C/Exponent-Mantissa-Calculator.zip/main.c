#include <stdio.h>
#include <stdlib.h>
#include <ieee754.h>
int main(){
float a;
for(;;){
printf("\n\nENTER the value of a:\n");
scanf("%f", &a);
union ieee754_float *p_a;
unsigned int a_exp;
unsigned int a_negative;
unsigned int a_mantissa;
p_a = (union ieee754_float*)&a;
a_exp = p_a->ieee.exponent;
a_negative = p_a->ieee.negative;
a_mantissa = p_a->ieee.mantissa;
printf("exponent of a: %x\n", a_exp);
printf("negative of a: %x\n", a_negative);
printf("mantissa of a: %x\n", a_mantissa);
 }
return 0;
}
